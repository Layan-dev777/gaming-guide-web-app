const searchInput = document.getElementById('search-input');
const searchButton = document.getElementById('search-button');
const cards = document.querySelectorAll('.card');

searchButton.addEventListener('click', function () {
    const query = searchInput.value.toLowerCase().trim();
    cards.forEach(card => {
        const cardText = card.innerText.toLowerCase();
        if (cardText.includes(query)) {
            card.style.display = 'block';
        } else {
            card.style.display = 'none';
        }
    });
});
const resetButton = document.getElementById('reset-button');
resetButton.addEventListener('click', function () {
    searchInput.value = ''; 
    cards.forEach(card => {
        card.style.display = 'block';
    });
});
const noResultsMessage = document.getElementById('no-results');

searchButton.addEventListener('click', function () {
    const query = searchInput.value.toLowerCase().trim();
    let hasResults = false;
    cards.forEach(card => {
        const cardText = card.innerText.toLowerCase();
        if (cardText.includes(query)) {
            card.style.display = 'block';
            hasResults = true;
        } else {
            card.style.display = 'none';
        }
    });

    noResultsMessage.style.display = hasResults ? 'none' : 'block';
});
